#include <pmm.h>

/**
 * @brief      Do nothing here in lab 1
 */
void pmm_init(void) {}
